## Prerequisites

* Ingescape C library installed
* Python3 (https://www.python.org/downloads/)

## Install dependencies
```bash
python3 -m pip install ingescape
```

## Run
```bash
python3 main.py
```



