package fr.gdai.ap.domain;

public class MyIngredient {
    private String text;
}
