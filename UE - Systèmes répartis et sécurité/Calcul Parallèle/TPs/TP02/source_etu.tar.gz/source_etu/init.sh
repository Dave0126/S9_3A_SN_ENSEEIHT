#!/bin/bash
SIMGRID=/mnt/n7fs/ens/tp_guivarch/opt2021/simgrid-3.31

export PATH=${SIMGRID}/bin:${PATH}
