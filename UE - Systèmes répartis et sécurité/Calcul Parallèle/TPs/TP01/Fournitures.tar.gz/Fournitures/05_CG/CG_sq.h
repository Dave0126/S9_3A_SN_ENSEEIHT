void cg_sq(double *A, double *rhs, int N, double tol);
