void cg_par(double *A_local, double *rhs, int N, int b, float tol);
